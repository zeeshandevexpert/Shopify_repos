

document.getElementById("popup_button").addEventListener("click", function(){
    document.getElementById('popup-contact-form').style.display='block';
});

document.getElementById("close-popup").addEventListener("click", function(){
    document.getElementById('popup-contact-form').style.display='none';
});
  

